function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}



if (document.readyState == 'loading') {
    document.addEventListener('DOMContentLoaded', ready)
} else {
    ready()
}

function ready() {
    var removeritemcarrinhobtn = document.getElementsByClassName('btn-lixo')
    for (var i = 0; i < removeritemcarrinhobtn.length; i++) {
        var btn = removeritemcarrinhobtn[i]
        btn.addEventListener('click', removeCartItem)
    }

    var quantityInputs = document.getElementsByClassName('carr-quantidade-imput')
    for (var i = 0; i < quantityInputs.length; i++) {
        var input = quantityInputs[i]
        input.addEventListener('change', quantityChanged)
    }

    var addToCartButtons = document.getElementsByClassName('loja-item-btn')
    for (var i = 0; i < addToCartButtons.length; i++) {
        var btn = addToCartButtons[i]
        btn.addEventListener('click', addToCartClicked)
    }

    document.getElementsByClassName('btn-pagar')[0].addEventListener('click', pagarclick)
}

function pagarclick() {
    alert('Obrigado pela sua compra')
    var cartItems = document.getElementsByClassName('cart-items')[0]
    while (cartItems.hasChildNodes()) {
        cartItems.removeChild(cartItems.firstChild)
    }
    updateCartTotal()
}

function removeCartItem(event) {
    var buttonClicked = event.target
    buttonClicked.parentElement.parentElement.remove()
    updateCartTotal()
}

function quantityChanged(event) {
    
    
    
    var input = event.target
    if (isNaN(input.value) || input.value <= 0) {
        input.value = 1
    }
    updateCartTotal()
}

function addToCartClicked(event) {
    var btn = event.target
    var shopItem = btn.parentElement.parentElement
    var title = shopItem.getElementsByClassName('titulo-img')[0].innerText
    var preco = shopItem.getElementsByClassName('preco-produto')[0].innerText
    var imageSrc = shopItem.getElementsByClassName('img-menu')[0].src
    addItemToCart(title, preco, imageSrc)
    updateCartTotal()
    
}



function addItemToCart(title, preço, imageSrc) {
    var cartRow = document.createElement('div')
    cartRow.classList.add('cart-row')
    var cartItems = document.getElementsByClassName('cart-items')[0]
    var cartItemNames = cartItems.getElementsByClassName('tituloo-carinho')
    for (var i = 0; i < cartItemNames.length; i++) {
        if (cartItemNames[i].innerText == title) {
            alert('Este item foi adicionado ao seu carrinho')
            return
        }
    }
    var cartRowContents = `
        <div class="item-carr coluna-pag">
            <img class="cart-img" src="${imageSrc}" width="100" height="100">
            <span class="tituloo-carinho">${title}</span>
        </div>
        <span class="precao-carr coluna-pag">${preço}</span>
        <div class="cart-quantity coluna-pag">
            <input class="carr-quantidade-imput" type="number" value="1">
           
    <i class="fa fa-trash btn-lixo"></i>
        </div>`
    cartRow.innerHTML = cartRowContents
    cartItems.append(cartRow)
    cartRow.getElementsByClassName('btn-lixo')[0].addEventListener('click', removeCartItem)
    cartRow.getElementsByClassName('carr-quantidade-imput')[0].addEventListener('change', quantityChanged)
    
    
      
}


    







function updateCartTotal() {
    var cartItemContainer = document.getElementsByClassName('cart-items')[0]
    var cartRows = cartItemContainer.getElementsByClassName('cart-row')
    var total = 0
    for (var i = 0; i < cartRows.length; i++) {
        var cartRow = cartRows[i]
        var priceElement = cartRow.getElementsByClassName('precao-carr')[0]
        var quantityElement = cartRow.getElementsByClassName('carr-quantidade-imput')[0]
        var preco = parseFloat(priceElement.innerText.replace('€', ''))
        var quantity = quantityElement.value
        total = total + (preco * quantity)
    }
    total = Math.round(total * 100) / 100
    document.getElementsByClassName('carr-total-prico')[0].innerText = '€' + total
 
    
    
    
    
    
    paypal.Buttons({

            // Set up the transaction
            createOrder: function(data, actions) {
                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            value: document.getElementsByClassName('carr-total')[0].innerText = '€' + total 
                        }
                    }]
                });
            },

            // Finalize the transaction
            onApprove: function(data, actions) {
                return actions.order.capture().then(function(details) {
                    // Show a success message to the buyer
                    alert('Transaction completed by ' + details.payer.name.given_name + '!');
                });
            }


        });
}




        
        paypal.Buttons({

            style: {
                color:  'blue',
                shape:  'pill',
                label:  'pay',
                height: 40
            }

        }).render('#paypal-button-container');
        

  
  
  
  
  var modal = document.getElementById("myModal");


var btn = document.getElementById("add-com-janela");


var span = document.getElementsByClassName("close")[0];


btn.onclick = function() {
  modal.style.display = "block";
}


span.onclick = function() {
  modal.style.display = "none";
}


window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} 



  var modal = document.getElementById("modalC");


var btn = document.getElementById("add-com-janelaC");





btn.onclick = function() {
  modal.style.display = "block";
}


span.onclick = function() {
  modal.style.display = "none";
}


window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} 




var modal = document.getElementById("modalC");


var btn = document.getElementById("add-com-janelaV");





btn.onclick = function() {
  modal.style.display = "block";
}


span.onclick = function() {
  modal.style.display = "none";
}


window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} 





